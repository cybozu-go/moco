# Change Log

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## [0.26.0] - 2026-07-01
### Changed
- Bump version to v0.36.0 [#927](https://github.com/cybozu-go/moco/pull/927)

## [0.25.0] - 2026-05-13
### Changed
- Bump version to v0.35.0 [#916](https://github.com/cybozu-go/moco/pull/916)

## [0.24.0] - 2026/02/19
### Changed
- Bump version to v0.34.0 [#889](https://github.com/cybozu-go/moco/pull/889)

## [0.23.0] - 2026/01/23
### Changed
- Bump appVersion to 0.33.0 [#873](https://github.com/cybozu-go/moco/pull/873)

## [0.22.0] - 2026/01/19
### Changed
- Bump appVersion to 0.32.0 [#868](https://github.com/cybozu-go/moco/pull/868)

## [0.21.0] - 2025-12-09
### Added
- Added `(agent,fluentbit).image.(repository,tag)` values, to set `--agent-image` and `--fluent-bit-image` args on controller [#827](https://github.com/cybozu-go/moco/pull/827)
- Bump appVersion to 0.31.0 [#864](https://github.com/cybozu-go/moco/pull/864)

### Contributors
- @dmaes

## [0.20.0] - 2025-09-26
### Changed
- Bump appVersion to 0.30.0 [#840](https://github.com/cybozu-go/moco/pull/840)

## [0.19.0] - 2025-09-10
### Changed
- Bump appVersion to 0.29.0 [#832](https://github.com/cybozu-go/moco/pull/832)

## [0.18.0] - 2025/08/06
### Changed
- Bump appVersion to 0.28.0 [#824](https://github.com/cybozu-go/moco/pull/824)

## [0.17.1] - 2025/05/28
### Changed
- Bump appVersion to 0.27.1 [#808](https://github.com/cybozu-go/moco/pull/808)

## [0.17.0] - 2025/05/27
### Changed
- Bump appVersion to 0.27.0 [#804](https://github.com/cybozu-go/moco/pull/804)

## [0.16.0] - 2024-03-05
### Changed
- Bump appVersion to 0.26.0 [#786](https://github.com/cybozu-go/moco/pull/786)

## [0.15.1] - 2024-12-03
### Changed
- Bump appVersion to 0.25.1 [#764](https://github.com/cybozu-go/moco/pull/764)

## [0.15.0] - 2024-11-20
### Changed
- Bump appVersion to 0.25.0 [#756](https://github.com/cybozu-go/moco/pull/756)

## [0.14.0] - 2024-09-20
### Changed
- Bump appVersion to 0.24.1 [#742](https://github.com/cybozu-go/moco/pull/742)

## [0.13.1] - 2024-07-02
### Changed
- Bump appVersion to 0.23.2 [#712](https://github.com/cybozu-go/moco/pull/712)

## [0.13.0] - 2024-06-25
### Changed
- Bump appVersion to 0.23.1 [#703](https://github.com/cybozu-go/moco/pull/703)

## [0.12.0] - 2024-06-21
### Changed
- Bump appVersion to 0.22.1 [#700](https://github.com/cybozu-go/moco/pull/700)

## [0.11.0] - 2024-06-14
### Caution
This release introduces the `crds.enabled` parameter to the Helm Chart.

When updating to a new chart from chart v0.10.x or lower, you **MUST** leave this parameter `true` (the default value).
If you turn off this option when updating, the CRD will be removed, causing data loss.

### Changed
- chart: add value to set a PriorityClass [#661](https://github.com/cybozu-go/moco/pull/661)
- Helm chart CRDs optional and not deleted on uninstall [#684](https://github.com/cybozu-go/moco/pull/684), [685](https://github.com/cybozu-go/moco/pull/685)
- Add basic Helm chart values [#687](https://github.com/cybozu-go/moco/pull/687)

### Contributors
- @npdgm
- @vholer

## [0.10.2] - 2024-03-08
### Changed
- Bump appVersion to 0.20.2 [#650](https://github.com/cybozu-go/moco/pull/650)

## [0.10.1] - 2024-01-24
### Changed
- Bump appVersion to 0.20.1 [#642](https://github.com/cybozu-go/moco/pull/642)

## [0.10.0] - 2023-12-20
### Changed
- Bump appVersion to 0.20.0 [#627](https://github.com/cybozu-go/moco/pull/627)

## [0.9.0] - 2023-11-14
### Changed
- Bump appVersion to 0.19.0 [#610](https://github.com/cybozu-go/moco/pull/610)

## [0.8.0] - 2023-11-02
### Changed
- Bump appVersion to 0.18.1 [#598](https://github.com/cybozu-go/moco/pull/598)

## [0.7.0] - 2023-09-12

### Changed
- Bump appVersion to 0.17.0. [#569](https://github.com/cybozu-go/moco/pull/569)

### Fixed
- Set kubeVersion compatible with EKS [#536](https://github.com/cybozu-go/moco/pull/536)

### Contributors
- @fgeorgeanybox

## [0.6.0] - 2023-04-06

### Changed
- Bump appVersion to 0.16.1. [#521](https://github.com/cybozu-go/moco/pull/521)

## [0.5.0] - 2023-02-24

### Changed
- Bump appVersion to 0.15.0. [#511](https://github.com/cybozu-go/moco/pull/511)

## [0.4.1] - 2022-12-09

### Changed
- Relax the kubeVersion constraints in Chart.yaml [#487](https://github.com/cybozu-go/moco/pull/487)
- Bump appVersion to 0.14.1. [#489](https://github.com/cybozu-go/moco/pull/489)

## [0.4.0] - 2022-11-29

### Added
- Add topologySpreadConstraints helm chart value [#455](https://github.com/cybozu-go/moco/pull/455)
- Add extraArgs to helm values [#466](https://github.com/cybozu-go/moco/pull/466)
- Specify minimum Kubernetes version [#468](https://github.com/cybozu-go/moco/pull/468)

## [0.3.0] - 2022-09-12

This release has breaking changes to the helm chart.
If you installed the chart with a release name other than `moco`, please migrate following [this procedure](./README.md#migrate-to-v030).

### Added
- Add helm chart values (#450)

### Changed
- Bump appVersion to 0.13.0.
- Rename helm resources (#432, #440)

## [0.2.3] - 2022-04-26

### Changed
- Bump appVersion to 0.12.1.

## [0.2.2] - 2022-04-22

### Changed
- Bump appVersion to 0.12.0.

## [0.2.1] - 2022-03-16

### Changed
- Bump appVersion to 0.11.1.

## [0.2.0] - 2022-03-07

### Support MySQLCluster v1beta2 API

The addition of the API adds a conversion webhook to the CRD.
Starting with this version, the CRD will be included in the Helm Chart template in MOCO
because the definition of the CRD conversion webhook needs to be changed
based on the namespace where the Helm chart is installed.

> :note: Helm standard CRD management does not support CRD configuration. (refs: [helm/helm#7735](https://github.com/helm/helm/issues/7735))

This will cause an error when upgrading from the previous chart, requiring a manual operation.

```console
$ helm upgrade -n moco-system moco moco/moco
Error: UPGRADE FAILED: rendered manifests contain a resource that already exists. Unable to continue with update: CustomResourceDefinition "backuppolicies.moco.cybozu.com" in namespace "" exists and cannot be imported into the current release: invalid ownership metadata; label validation error: missing key "app.kubernetes.io/managed-by": must be set to "Helm"; annotation validation error: missing key "meta.helm.sh/release-name": must be set to "moco"; annotation validation error: missing key "meta.helm.sh/release-namespace": must be set to "moco-system"
```

Exec the following command to add annotations and labels to the CRD:

```console
$ kubectl annotate crd mysqlclusters.moco.cybozu.com meta.helm.sh/release-name='<YOUR RELEASE NAME>'
$ kubectl annotate crd backuppolicies.moco.cybozu.com meta.helm.sh/release-name='<YOUR RELEASE NAME>'
$ kubectl annotate crd mysqlclusters.moco.cybozu.com meta.helm.sh/release-namespace='<YOUR RELEASE NAMESPACE>'
$ kubectl annotate crd backuppolicies.moco.cybozu.com meta.helm.sh/release-namespace='<YOUR RELEASE NAMESPACE>'
$ kubectl label crd mysqlclusters.moco.cybozu.com app.kubernetes.io/managed-by='Helm'
$ kubectl label crd backuppolicies.moco.cybozu.com app.kubernetes.io/managed-by='Helm'
```

If the labels and annotations are set properly, the upgrade will be successful.

```console
$ helm upgrade -n moco-system moco moco/moco
Release "moco" has been upgraded. Happy Helming!
NAME: moco
LAST DEPLOYED: Tue Dec  7 22:43:30 2021
NAMESPACE: moco-system
STATUS: deployed
REVISION: 2
TEST SUITE: None
```

### Changed
- Bump appVersion to 0.11.0.

## [0.1.2] - 2021-11-18

### Changed
- Bump appVersion to 0.10.9.

## [0.1.1] - 2021-11-12

### Changed
- Bump appVersion to 0.10.8.

## [0.1.0] - 2021-11-02

This is the first release.

[Unreleased]: https://github.com/cybozu-go/moco/compare/chart-v0.26.0...HEAD
[0.26.0]: https://github.com/cybozu-go/moco/compare/chart-v0.25.0...chart-v0.26.0
[0.25.0]: https://github.com/cybozu-go/moco/compare/chart-v0.24.0...chart-v0.25.0
[0.24.0]: https://github.com/cybozu-go/moco/compare/chart-v0.23.0...chart-v0.24.0
[0.23.0]: https://github.com/cybozu-go/moco/compare/chart-v0.22.0...chart-v0.23.0
[0.22.0]: https://github.com/cybozu-go/moco/compare/chart-v0.21.0...chart-v0.22.0
[0.21.0]: https://github.com/cybozu-go/moco/compare/chart-v0.20.0...chart-v0.21.0
[0.20.0]: https://github.com/cybozu-go/moco/compare/chart-v0.19.0...chart-v0.20.0
[0.19.0]: https://github.com/cybozu-go/moco/compare/chart-v0.18.0...chart-v0.19.0
[0.18.0]: https://github.com/cybozu-go/moco/compare/chart-v0.17.1...chart-v0.18.0
[0.17.1]: https://github.com/cybozu-go/moco/compare/chart-v0.17.0...chart-v0.17.1
[0.17.0]: https://github.com/cybozu-go/moco/compare/chart-v0.16.0...chart-v0.17.0
[0.16.0]: https://github.com/cybozu-go/moco/compare/chart-v0.15.1...chart-v0.16.0
[0.15.1]: https://github.com/cybozu-go/moco/compare/chart-v0.15.0...chart-v0.15.1
[0.15.0]: https://github.com/cybozu-go/moco/compare/chart-v0.14.0...chart-v0.15.0
[0.14.0]: https://github.com/cybozu-go/moco/compare/chart-v0.13.1...chart-v0.14.0
[0.13.1]: https://github.com/cybozu-go/moco/compare/chart-v0.13.0...chart-v0.13.1
[0.13.0]: https://github.com/cybozu-go/moco/compare/chart-v0.12.0...chart-v0.13.0
[0.12.0]: https://github.com/cybozu-go/moco/compare/chart-v0.11.0...chart-v0.12.0
[0.11.0]: https://github.com/cybozu-go/moco/compare/chart-v0.10.2...chart-v0.11.0
[0.10.2]: https://github.com/cybozu-go/moco/compare/chart-v0.10.1...chart-v0.10.2
[0.10.1]: https://github.com/cybozu-go/moco/compare/chart-v0.10.0...chart-v0.10.1
[0.10.0]: https://github.com/cybozu-go/moco/compare/chart-v0.9.0...chart-v0.10.0
[0.9.0]: https://github.com/cybozu-go/moco/compare/chart-v0.8.0...chart-v0.9.0
[0.8.0]: https://github.com/cybozu-go/moco/compare/chart-v0.7.0...chart-v0.8.0
[0.7.0]: https://github.com/cybozu-go/moco/compare/chart-v0.6.0...chart-v0.7.0
[0.6.0]: https://github.com/cybozu-go/moco/compare/chart-v0.5.0...chart-v0.6.0
[0.5.0]: https://github.com/cybozu-go/moco/compare/chart-v0.4.1...chart-v0.5.0
[0.4.1]: https://github.com/cybozu-go/moco/compare/chart-v0.4.0...chart-v0.4.1
[0.4.0]: https://github.com/cybozu-go/moco/compare/chart-v0.3.0...chart-v0.4.0
[0.3.0]: https://github.com/cybozu-go/moco/compare/chart-v0.2.3...chart-v0.3.0
[0.2.3]: https://github.com/cybozu-go/moco/compare/chart-v0.2.2...chart-v0.2.3
[0.2.2]: https://github.com/cybozu-go/moco/compare/chart-v0.2.1...chart-v0.2.2
[0.2.1]: https://github.com/cybozu-go/moco/compare/chart-v0.2.0...chart-v0.2.1
[0.2.0]: https://github.com/cybozu-go/moco/compare/chart-v0.1.2...chart-v0.2.0
[0.1.2]: https://github.com/cybozu-go/moco/compare/chart-v0.1.1...chart-v0.1.2
[0.1.1]: https://github.com/cybozu-go/moco/compare/chart-v0.1.0...chart-v0.1.1
[0.1.0]: https://github.com/cybozu-go/moco/releases/tag/chart-v0.1.0
